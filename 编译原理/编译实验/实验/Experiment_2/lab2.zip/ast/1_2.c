int main2()
{
    int b1;
    int b2;
    int b3;
    b1 = b2 + b3;
}
